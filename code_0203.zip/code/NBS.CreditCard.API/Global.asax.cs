﻿using NBS.CreditCard.API.Serivces;
using NBS.CreditCard.API.Services;
using SimpleInjector;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Dependencies;
using System.Web.Routing;

namespace NBS.CC
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);

            var container = new Container();
            container.Register<IMongoDBService, MongoDBService>();

            container.Verify();
            GlobalConfiguration.Configuration.DependencyResolver = new SimpleInjectorDependecyResolver(container);


        }
    }
}
