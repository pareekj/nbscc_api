﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace NBS.CreditCard.API.Serivces
{
    public class MongoDBContext
    {
        public MongoClient client;
        //private MongoServer _server;
        //private MongoDatabase _database;

        public MongoDBContext()
        {
            var MongoDbHost = ConfigurationManager.AppSettings["MongoHost"];  //localhost  
            var MongoDb = ConfigurationManager.AppSettings["MongoDatabaseName"]; //Database  

            var settings = new MongoClientSettings
            {
                Server = new MongoServerAddress(MongoDbHost)
            };

            //_client = new MongoClient(settings);
            //_client.GetDatabase(MongoDb)
        }

        
    }
}