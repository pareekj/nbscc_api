﻿using SimpleInjector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Dependencies;

namespace NBS.CreditCard.API.Serivces
{
    public class SimpleInjectorDependecyResolver : IDependencyResolver, IDependencyScope
    {
        public Container container { get; private set; }

        public SimpleInjectorDependecyResolver(Container container)
        {
            if (container == null)
                throw new ArgumentNullException("container");
            this.container = container;
        }

        public IDependencyScope BeginScope()
        {
            return this;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public object GetService(Type serviceType)
        {
            return ((IServiceProvider)this.container).GetService(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return this.container.GetAllInstances(serviceType);
        }

        object IDependencyScope.GetService(Type serviceType)
        {
            return ((IServiceProvider)this.container).GetService(serviceType);
        }

        IEnumerable<object> IDependencyScope.GetServices(Type serviceType)
        {
            IServiceProvider provider = container;
            Type CollectionType = typeof(IEnumerable<>).MakeGenericType(serviceType);
            var services = (IEnumerable<object>)provider.GetService(CollectionType);

            return services ?? Enumerable.Empty<object>(); 
        }

        void IDisposable.Dispose() { }
    }
}