﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using MongoDB.Driver;
using System.Configuration;

namespace NBS.CreditCard.API.Services
{
    public class MongoDBService : IMongoDBService
    {
        private static MongoClient client;

        private static object syncLock = new object();

        public IMongoDatabase GetDBContext()
        {
            var MongoDbHostName = ConfigurationManager.AppSettings["MongoDbHost"];  //localhost 
            var MongoDbHostPort = ConfigurationManager.AppSettings["MongoDbPort"];  //localhost  
            var MongoDbName = ConfigurationManager.AppSettings["MongoDbName"]; //Database  
            

            var settings = new MongoClientSettings
            {
                Server = new MongoServerAddress(MongoDbHostName, Convert.ToInt32(MongoDbHostPort))
            };

            if (client == null)
            {
                lock (syncLock);
                if (client == null)
                    //client = new MongoClient(settings);
                    client = new MongoClient(MongoDbHostName);
            }
            //return client.GetDatabase("test");
            return client.GetDatabase(MongoDbName);
        }
    }
}