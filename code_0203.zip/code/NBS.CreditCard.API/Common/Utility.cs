﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NBS.CreditCard.API.Common
{
    public static class Utility
    {
        public static bool ValidLucnCheckSum(string IdNumber, int ValidLength)
        {
            if (IdNumber.Length != ValidLength)
                return false;

            long Number;
            bool IsNumeric = long.TryParse(IdNumber, out Number);
            if (!IsNumeric)
                return false;

            int Sum = int.Parse(IdNumber.ElementAt(ValidLength - 1).ToString());
            int Parity = (ValidLength) % 2;

            for (int index = 0; index < ValidLength - 1; index++)
            {
                int Digit = int.Parse(IdNumber.ElementAt(index).ToString());

                if (index % 2 == Parity)
                    Digit = Digit * 2;

                if (Digit > 9)
                    Digit = Digit - 9;

                Sum += Digit;
            }

            return ((Sum * 9) % 10 == 0);
        }
    }
}