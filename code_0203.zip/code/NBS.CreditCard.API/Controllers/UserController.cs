﻿using MongoDB.Bson;
using MongoDB.Driver;
using NBS.CreditCard.API.Controllers;
using NBS.CreditCard.API.Services;
using NBS.CreditCard.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace NBS.CreditCard.Controllers
{
    public class UserController : BaseController
    {
        private IMongoDBService dbService;

        public UserController(IMongoDBService dbService) : base()
        {
            this.dbService = dbService;
        }

        [Route("nbscc/users")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            var collection = dbService.GetDBContext().GetCollection<BsonDocument>(UserCollection);

            var document = collection.Find(new BsonDocument()).ToList();

            HttpResponseMessage response;
            response = Request.CreateResponse(System.Net.HttpStatusCode.OK);

            var jsonResult = Newtonsoft.Json.JsonConvert.SerializeObject(document);

            response.Content = new StringContent(jsonResult, Encoding.UTF8, "application/json");
            return response;

        }

        [Route("nbscc/users/{fname}")]
        [HttpGet]
        public HttpResponseMessage Get(string fname)
        {
            var collection = dbService.GetDBContext().GetCollection<User>(UserCollection);
            var filter = new BsonDocument("first_name", fname);

            var user = collection.Find(filter).FirstOrDefault();

            HttpResponseMessage response;
            response = Request.CreateResponse(System.Net.HttpStatusCode.OK);

            var result = user.ToString();

            var jsonResult = Newtonsoft.Json.JsonConvert.SerializeObject(user);

            response.Content = new StringContent(jsonResult, Encoding.UTF8, "application/json");

            return response;

        }

        [Route("nbscc/users")]
        [HttpPost]
        public IHttpActionResult Post(User user)
        {
            var collection = dbService.GetDBContext().GetCollection<User>(UserCollection);

            collection.InsertOne(user);

            HttpResponseMessage response;
            response = Request.CreateResponse(System.Net.HttpStatusCode.OK);

            var result = user.ToString();

            var jsonResult = Newtonsoft.Json.JsonConvert.SerializeObject(result);

            response.Content = new StringContent(jsonResult, Encoding.UTF8, "application/json");

            return Ok(user);

        }

        [Route("nbscc/users/{id}")]
        [HttpPut]
        public IHttpActionResult Put(string id, User user)
        {
            var collection = dbService.GetDBContext().GetCollection<User>(UserCollection);


            user.Id = new ObjectId(id);
            var filter = Builders<User>.Filter.Eq("Id", ObjectId.Parse(id));

//            var selectedUser = collection.Find(filter).FirstOrDefault();

            
            var update = Builders<User>.Update.Set("first_name", user.FirstName)
                                                .Set("last_name", user.LastName);

            collection.UpdateOne(filter, update);
             
            HttpResponseMessage response;
            response = Request.CreateResponse(System.Net.HttpStatusCode.OK);

            return Ok();

        }

        [Route("nbscc/users/{id}")]
        [HttpDelete]
        public IHttpActionResult Delete(string id)
        {
            var collection = dbService.GetDBContext().GetCollection<User>(UserCollection);


            var filter = Builders<User>.Filter.Eq("Id", ObjectId.Parse(id));

            var result = collection.DeleteOne(filter);


            HttpResponseMessage response;
            response = Request.CreateResponse(System.Net.HttpStatusCode.OK);

            return Ok();

        }


    }
}
