﻿using NBS.CreditCard.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using NBS.CreditCard.Models;
using System.Text;
using MongoDB.Bson;
using MongoDB.Driver;
using NBS.CreditCard.API.Validators;
using FluentValidation.Results;

namespace NBS.CreditCard.API.Controllers
{
    public class CreditCardsController : BaseController
    {
        private IMongoDBService dbService;

        public CreditCardsController(IMongoDBService dbService) : base()
        {
            this.dbService = dbService;
        }

        [Route("creditcards/{number}")]
        [HttpGet]
        public HttpResponseMessage Get(string Number)
        {
            NBS.CreditCard.Models.CreditCard Card = (NBS.CreditCard.Models.CreditCard)FindCreditCardByNumber(Number);

            if (Card == null)
            {
                Response = Request.CreateErrorResponse((HttpStatusCode)404, "Card does not exist");
                return Response;
            }

            Response = this.Request.CreateResponse(System.Net.HttpStatusCode.OK);
            var jsonResult = Newtonsoft.Json.JsonConvert.SerializeObject(Card);

            Response.Content = new StringContent(jsonResult, Encoding.UTF8, "application/json");

            return Response;

        }

        [Route("creditcards/")]
        [HttpPost]
        public HttpResponseMessage Post(NBS.CreditCard.Models.CreditCard NewCard)
        {
            var ccValidator = new CreditCardValidator();
            ValidationResult results = ccValidator.Validate(NewCard);
            bool success = results.IsValid;

            if (!success)
            {
                IList<ValidationFailure> failures = results.Errors;
                Response = Request.CreateErrorResponse((HttpStatusCode)434, failures[0].ToString());
                return Response;
            }

            NBS.CreditCard.Models.CreditCard Card = (NBS.CreditCard.Models.CreditCard)FindCreditCardByNumber(NewCard.Number.ToString());

            if (Card != null)
            {
                Response = Request.CreateErrorResponse((HttpStatusCode)422, "Card already exists");
                return Response;
            }

            var collection = dbService.GetDBContext().GetCollection<NBS.CreditCard.Models.CreditCard>(CreditCardCollection);
            var filter = new BsonDocument("number", NewCard.Number);

            try
            {
                collection.InsertOne(NewCard);
                Response = Request.CreateResponse(System.Net.HttpStatusCode.Created);
            }
            catch
            {
                Response = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Unexpected error occurred. Please try later");
            }
            
            return Response;

        }

        [Route("creditcards/{number}")]
        [HttpPatch]
        public HttpResponseMessage Patch(string Number, NBS.CreditCard.Models.Transaction CardTxn)
        {
            NBS.CreditCard.Models.CreditCard Card = (NBS.CreditCard.Models.CreditCard)FindCreditCardByNumber(Number);

            if (Card == null)
            {
                Response = Request.CreateErrorResponse((HttpStatusCode)404, "Card does not exist");
                return Response;
            }

            double NewBalance = ((NBS.CreditCard.Models.CreditCard)Card).Balance + CardTxn.Amount;

            var collection = dbService.GetDBContext().GetCollection<NBS.CreditCard.Models.CreditCard>(CreditCardCollection);

            var filter = new BsonDocument("number", long.Parse(Number));
            var update = Builders<NBS.CreditCard.Models.CreditCard>.Update.Set("balance", NewBalance);

            collection.UpdateOne(filter, update);

            Response = Request.CreateResponse(System.Net.HttpStatusCode.OK);
            
            return Response;
        }

        [Route("creditcards/{number}")]
        [HttpDelete]
        public HttpResponseMessage Delete(string Number)
        {
            NBS.CreditCard.Models.CreditCard Card = (NBS.CreditCard.Models.CreditCard)FindCreditCardByNumber(Number);

            if (Card == null)
            {
                Response = Request.CreateErrorResponse((HttpStatusCode)404, "Card does not exist");
                return Response;
            }

            var collection = dbService.GetDBContext().GetCollection<NBS.CreditCard.Models.CreditCard>(CreditCardCollection);
            var filter = new BsonDocument("number", long.Parse(Number));

            var result = collection.DeleteOne(filter);
            
            Response = Request.CreateResponse(System.Net.HttpStatusCode.OK);

            return Response;

        }

        [Route("creditcards/{param1}/{param2}")]
        [HttpGet]
        public HttpResponseMessage Test(string param1, string param2)
        {
            Response = this.Request.CreateResponse(System.Net.HttpStatusCode.OK);
            var jsonResult = "Status: " + System.Net.HttpStatusCode.OK.ToString() + "\nInput: " + param1 + " " + param2;

            Response.Content = new StringContent(jsonResult, Encoding.UTF8, "application/json");

            return Response;

        }

        private object FindCreditCardByNumber(string Number)
        {
            var collection = dbService.GetDBContext().GetCollection<NBS.CreditCard.Models.CreditCard>(CreditCardCollection);

            var filter = new BsonDocument("number", long.Parse(Number));
            var card = collection.Find(filter).FirstOrDefault();

            return card;
        }
    }
}
