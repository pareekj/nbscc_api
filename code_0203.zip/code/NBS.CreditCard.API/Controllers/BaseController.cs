﻿using NBS.CreditCard.API.Services;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace NBS.CreditCard.API.Controllers
{
    public class BaseController : ApiController
    {
        public HttpResponseMessage Response;
        public string UserCollection { get; private set; }
        public string CreditCardCollection { get; private set; }

        public BaseController()
        {
            this.UserCollection = ConfigurationManager.AppSettings["MongoCollectionName"];
            this.CreditCardCollection = ConfigurationManager.AppSettings["MongoCCCollectionName"];
        }
    }
}
