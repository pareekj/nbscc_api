﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NBS.CreditCard.Controllers;
using System.Net.Http;
using System.Web;
using NBS.CreditCard.Models;
using System.Web.Http;
using NBS.CreditCard.API.Controllers;
using NBS.CreditCard.API.Services;

namespace NBS.CreditCard.API.Tests
{
    [TestClass]
    public class UnitTestCreditCardController
    {
        private static CreditCardsController controller;
        private static object syncLock = new object();

        private CreditCardsController GetController()
        {
            if (controller == null)
            {
                lock (syncLock) ;
                if (controller == null) {
                    IMongoDBService service = new MongoDBService();
                    controller = new CreditCardsController(service);
                }
            }

            return controller;
        }

        [TestMethod]
        public void LuhnCheckSum()
        {
            bool result = NBS.CreditCard.API.Common.Utility.ValidLucnCheckSum("373399017375309", 15);
            Assert.AreEqual(true, result);
        }

        [TestMethod]
        public void TestCreditCardGetSuccess()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            HttpResponseMessage response = GetController().Get("30540669277070");

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.OK);
        }

        [TestMethod]
        public void TestCreditCardGetNotFound()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            HttpResponseMessage response = GetController().Get("47347327498");

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.NotFound);
        }

        [TestMethod]
        public void TestCreditCardPostSuccess()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            NBS.CreditCard.Models.CreditCard cc = new Models.CreditCard();
            
            cc.Number = 5018335736811687;
            cc.ExpiryMonth = 10;
            cc.ExpiryYear = 2021;
            cc.CVV = 826;
            cc.CardHolderName = "John Smith";
            cc.Balance = -2821.23;

            HttpResponseMessage response = GetController().Post(cc);

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.Created);
        }
        [TestMethod]
        public void TestCreditCardPostAlreadyExists()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            NBS.CreditCard.Models.CreditCard cc = new Models.CreditCard();

            cc.Number = 5018335736811687;
            cc.ExpiryMonth = 10;
            cc.ExpiryYear = 2021;
            cc.CVV = 826;
            cc.CardHolderName = "John Smith";
            cc.Balance = -2821.23;

            HttpResponseMessage response = GetController().Post(cc);

            Assert.AreEqual(response.StatusCode, (System.Net.HttpStatusCode)422);
        }
        [TestMethod]
        public void TestCreditCardPostInvalidCardNumber()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            NBS.CreditCard.Models.CreditCard cc = new Models.CreditCard();

            cc.Number = 50183357423211687;
            cc.ExpiryMonth = 10;
            cc.ExpiryYear = 2021;
            cc.CVV = 826;
            cc.CardHolderName = "John Smith";
            cc.Balance = -2821.23;

            HttpResponseMessage response = GetController().Post(cc);

            Assert.AreEqual(response.StatusCode, (System.Net.HttpStatusCode)434);
        }

        [TestMethod]
        public void TestCreditCardPatchSuccess()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            NBS.CreditCard.Models.Transaction ctxn = new NBS.CreditCard.Models.Transaction();

            ctxn.CCNumber = 6011232207874390;
            ctxn.Amount = -105.80;

            HttpResponseMessage response = GetController().Patch("6011232207874390", ctxn);

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.OK);
        }

        [TestMethod]
        public void TestCreditCardPatchNotFound()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());


            NBS.CreditCard.Models.Transaction ctxn = new NBS.CreditCard.Models.Transaction();

            ctxn.CCNumber = 5018374611687;
            ctxn.Amount = -105.80;

            HttpResponseMessage response = GetController().Patch("5018374611687", ctxn);

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.NotFound);
        }

        [TestMethod]
        public void TestCreditCardDeleteSuccess()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            HttpResponseMessage response = GetController().Delete("5018335736811687");

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.OK);
        }

        [TestMethod]
        public void TestCreditCardDeleteNotFound()
        {
            var controller = GetController();
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            HttpResponseMessage response = GetController().Delete("5018335383781687");

            Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.NotFound);
        }
    }
}
