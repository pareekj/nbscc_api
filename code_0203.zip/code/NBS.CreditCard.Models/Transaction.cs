﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBS.CreditCard.Models
{
    public class Transaction
    {
        public long CCNumber { get; set; }
        public double Amount { get; set; }
    }
}
