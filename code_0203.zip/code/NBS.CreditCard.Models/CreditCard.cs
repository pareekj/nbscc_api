﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBS.CreditCard.Models
{
    public class CreditCard
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("number")]
        public long Number { get; set; }

        [BsonElement("expirymonth")]
        public int ExpiryMonth { get; set; }

        [BsonElement("expiryyear")]
        public int ExpiryYear { get; set;}

        [BsonElement("cvv")]
        public int CVV { get; set; }

        [BsonElement("cardholder")]
        public string CardHolderName { get; set; }

        [BsonElement("balance")]
        public double Balance { get; set; }
    }
}
